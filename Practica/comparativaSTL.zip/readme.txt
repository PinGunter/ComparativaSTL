- Hemos incluido todos los archivos cpp, así como scripts para ejecutarlos con un número mayor de elementos en el contenedor.
- Los scripts usan "csh" y se deben ejecutar desde la carpeta raíz de cada estructura de dato.
- La información acerca de los tiempos y complejidad está en el pdf "Comparativa.pdf".
- Hemos incluido un makefile con opciones para compilarlo todo (por dejecto) o para elegir insercion, borrado, acceso o búsqueda.
- En algunas ocasiones, para evitar errores de precisión hemos ejecutado la operación 1000000 de veces y luego dividido el tiempo por ese número de veces.
- En otros casos, para poder obtener una vista más general hemos aumentado el tamaño del contenedor.

